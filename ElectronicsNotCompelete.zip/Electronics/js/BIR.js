////////////////////////////////////////////////////////////////////////////////////////Canvas
var cnvPrac = document.querySelector("#cnvPractical");
var ctx = cnvPrac.getContext("2d");
var ANGLE = Math.PI/180;


function drawWire(isOff){
    if(isOff){
        ctx.moveTo(415,285);
    }else{
        ctx.moveTo(415,310);
    }
    ctx.lineTo(390,310);
    ctx.lineTo(55,310);
    ctx.lineTo(55,55);
    ctx.lineTo(490,55);
    ctx.lineTo(490,310);
    ctx.lineTo(415,310);
    ctx.stroke();
    ctx.moveTo(135,310);
    ctx.lineTo(135,55);
    ctx.stroke();
}

drawWire(true);

var btryEValue = 5;
var btryRValue = 6;
var btry = new Image();
btry.src = "./res/battery.png";
btry.onload = function(){
    ctx.drawImage(btry,0,0,50,50,30,160,50,50);
    ctx.font = "16px Arial"
    ctx.fillText(btryEValue+" v",80,180);
}

var vmValue = 20;
var vm = new Image();
vm.src = "./res/voltmeter-64.png";
vm.onload = function(){
    ctx.drawImage(vm,110,160,50,50);
    ctx.font = "16px Arial"
    ctx.fillText(vmValue+" v",160,180);
}

var amValue = 0.0;
var am = new Image();
am.src = "./res/ampere-meter-48.png";
am.onload = function(){
    ctx.drawImage(am,230,280,50,50);
    ctx.font = "16px Arial"
    ctx.fillText(amValue+" mA",230,340);
}

var vrValue = 40;
var vr = new Image();
vr.src = "./res/vRes.png";
vr.onload = function(){
    ctx.drawImage(vr,240,30,50,50);
    ctx.font = "16px Arial"
    ctx.fillText(vrValue+" ohm",240,80);
}

var resValue = 10;
var res = new Image();
res.src = "./res/resister.png";
res.onload = function(){
    ctx.drawImage(res,400,30,50,50);
    ctx.font = "16px Arial"
    ctx.fillText(resValue+" ohm",400,80);
}


//////////////////////////////////////////////////////////////////////////////////////////// functions

var btnRecord = document.querySelector("#btnRecord");
var tblData = document.querySelector("#dataTbl");
var btnDrawGraph = document.querySelector("#btnDrawGraph")
var tblValues = tblData.getElementsByTagName("td");

btnRecord.addEventListener("click",recordData);

function recordData(e){
    tblData.innerHTML += "<tr><td>"+amValue+"</td><td>"+vmValue+"</td></tr>";
}

btnDrawGraph.addEventListener("click",drawGrahp);

function drawGrahp(){
    var x = [];
    var y = [];
    for(i=0 ;i<tblValues.length ;i+=2){
        x.push(tblValues[i].innerHTML);
        y.push(tblValues[i+1].innerHTML);
    }
    drawChart(x,y);
}


/////////////////////////////////////////////////////////////////////////////////////////////// draw chart
function drawChart(x,y){
    $(document).ready(function() {
        var ctx = $("#grahpCanvas");
      
        var data = {
          labels: x,
          datasets: [
            {
              label: 'Read data',
              data:y,
              backgroundColor: '#00E0C1',
              borderColor: '#006E5E',
              fill: false,
              lineTension: 0,
              pointRadius: 5
            }
          ]
        };
      
        var options = {
          title: {
            display: true,
            position: 'top',
            text: 'Data Gragh',
            fontSize: 14,
            fontColor: '#111'
          },
          legend: {
            display: true,
            position: 'bottom'
          }
        }
      
        var chart = new Chart(ctx, {
          type: "line",
          data: data,
          options: options
        })
      });
}